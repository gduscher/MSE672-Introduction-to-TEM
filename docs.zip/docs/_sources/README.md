# MSE672: Introduction to TEM
MSE672: Course of the MSE Department at The University of Tennessee in the Spring Semester 2024

by Gerd Duscher, Khalid Hattar

Start with this [notebook](https://github.com/gduscher/MSE672-Introduction-to-TEM/blob/main/_MSE672_Intro_TEM.ipynb)

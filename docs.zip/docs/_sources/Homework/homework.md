<font size = "5"> **Chapter 2: Diffraction** </font>


<hr style="height:1px;border-top:4px solid #FF8200" />

# Homework


part of 

<font size = "5"> **[MSE672:  Introduction to Transmission Electron Microscopy](../_MSE672_Intro_TEM.ipynb)**</font>


by Gerd Duscher, Spring 2023

Microscopy Facilities<br>
Institute of Advanced Materials & Manufacturing<br>
Materials Science & Engineering<br>
The University of Tennessee, Knoxville

Background and methods to analysis and quantification of data acquired with transmission electron microscopes.


<font size = "5"> **Homework** </font>

In this folder are all notebooks necessary for the homework of this course